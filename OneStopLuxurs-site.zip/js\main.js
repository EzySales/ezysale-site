document.addEventListener('DOMContentLoaded', function () {
  var toggle = document.querySelector('.hamburger');
  var nav = document.querySelector('.main-nav');

  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      nav.classList.toggle('open');
    });
  }

  var form = document.querySelector('.contact-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var name = form.querySelector('#name').value.trim();
      var subject = encodeURIComponent('Enquiry from ' + name + ' — One Stop Luxurs website');
      var body = encodeURIComponent(
        'Name: ' + name + '\n' +
        'Email: ' + form.querySelector('#email').value.trim() + '\n' +
        'Phone: ' + form.querySelector('#phone').value.trim() + '\n' +
        'Interested in: ' + form.querySelector('#interest').value + '\n\n' +
        'Message:\n' + form.querySelector('#message').value.trim()
      );
      window.location.href = 'mailto:hr@onestopluxurs.com?subject=' + subject + '&body=' + body;
    });
  }
});
